export const CITY_READY = 'CITY_READY'
export const CITY_SET = 'CITY_SET'
export const CITY_CONFIRM = 'CITY_CONFIRM'
export const CITY_SET_QUERY = 'CITY_SET_QUERY'
